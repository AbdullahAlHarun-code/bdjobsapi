from django.contrib import admin
from .models import HotJob  # Replace with your actual model name

admin.site.register(HotJob)  # Register your model with the admin site